Cufon.replace('#menu a, h5, .footer_logo', { fontFamily: 'EB Garamond', hover:true });
Cufon.replace('h2', { fontFamily: 'CabinSketch', hover:true });
Cufon.replace('h4', { fontFamily: 'CabinSketch', hover:true, textShadow:'#000 0 0' });